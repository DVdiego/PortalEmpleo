/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pse.portalempleog6.subscribe;

import com.pse.portalempleog6.jaas.UserEJB;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author home
 */
@Named(value="userPayment")
@RequestScoped
public class UserPayment {
    
    
    Client client;
    WebTarget target;
    @Inject UserEJB ejb;
    
    @PostConstruct
    public void init(){
        client = ClientBuilder.newClient();
    }
    
    @PreDestroy
    public void destroy(){
        client.close();
        
    }
    
    
    public String checkPayment(){
        
        
        
        String emailUser = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();    
        String url = "http://valdavia.infor.uva.es:8080/pagos/webresources/usuarios/"+emailUser;       
        System.out.println(url);
        Users paymentStatus ;
        try{
               target = client.target(url);      
          
            paymentStatus = target.register(PaymentStatusReader.class).request().get(Users.class);
        } catch(Exception ex){
            paymentStatus = null;
        }
                
        if (paymentStatus != null) {
            if (paymentStatus.getPagado().contains("si")) {
                return "/faces/subscribe/subscriptionok.xhtml";
            }
            if (paymentStatus.getPagado().contains("no")) {
                return "/faces/subscribe/subscriptionerror.xhtml";
            }
        }
        return "/faces/subscribe/error.xhtml";
        
            
        
    }
    
}
